<?php
class DbImportModuleTaskModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function init()
    {
        parent::init();
    }

    public function initContent()
    {
        parent::initContent();
        $this->context->smarty->assign(array(
            'nb_product' => Db::getInstance()->executeS('select COUNT(*) from `'._DB_PREFIX_. 'leidimas`'),
//            'categories' => Db::getInstance()->executeS("")

        ));
        $this->setTemplate('module:dbimportmodule/views/templates/front/task.tpl');
    }
}