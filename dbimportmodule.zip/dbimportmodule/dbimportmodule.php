<?php
if (!defined('_PS_VERSION_')) {
    exit;
}
class DbImportModule extends Module
{

    protected $render_Form = false;
    public function __construct()
    {
        $this->name = 'dbimportmodule';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Mindaugas Andriusaitis';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();
        $this->confirmUninstall = $this->l('');
        $this->displayName = $this->l('Database Import Module');
        $this->description = $this->l('This module imports data from a database server into PrestaShop.');
    }
    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        return parent::install() &&
            $this->registerHook('displayHome') &&
            $this->registerHook('actionAdminControllerSetMedia')&&
            $this->registerHook('header') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('displayFooter');
    }

    public function hookActionAdminControllerSetMedia()
    {
        $this->context->controller->addJS($this->_path.'/views/js/dbimport.js');
    }
    public function uninstall()
    {

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submitDbImport')) {

            $server = Tools::getValue('DBIMPORTMODULE_SERVER');
            $username = Tools::getValue('DBIMPORTMODULE_USERNAME');
            $password = Tools::getValue('DBIMPORTMODULE_PASSWORD');
            $database = Tools::getValue('DBIMPORTMODULE_DATABASE');

            $conn = new mysqli($server, $username, $password, $database);
            $conn->set_charset("utf8");
            if ($conn->connect_error) {
                die('Connection failed: ' . $conn->connect_error());
            }

            $result = mysqli_query($conn, "SELECT katalogas.KatalogasID as model,
    leidimas.NomNr  as reference,
    leidimas.Svoris  as weight,
    leidykla.Pavadinimas as id_manufacturer,
    (SELECT struktura.Pavadinimas FROM Lala.struktura WHERE struktura.StrukturaID = busena.StrukturaId) as product_category,
    katalogas.Pavadinimas as name,
    leidimas.Anotacija as description,
    katalogas.Autorius as author,
    leidimas.ISBN as isbn,
    CONCAT_WS('<br>',CONCAT('http://158.129.1.14/knygos/action.php?file=bW9kdWxpc3dlYi9pbWFnZS5waHA=&img=', TO_BASE64(CONCAT('/storage/lala/virselis/virselis', leidimas_img.LeidimasID, '_original.jpg')))) as product_image,

    0 as quantity,
    0.0 as price,
    0.00 as cost,
    CONCAT_WS(
      '<br>',
      'Autorius',
      'Tipas 1',
      'Tipas 2',
      'Metai',
      'Leidimo nr.',
      'Puslapių sk.',
      'ISBN',
      'eMetai',
      'eISBN',
      'eISSN',
      'DOI',
      'Būsena',
      'Formatas',
      'Viršelio tipas'
    ) as attributes,
    CONCAT_WS(
      '<br>',
      katalogas.Autorius,
      leidimas.TipasTxt,
      CONCAT_WS(' ', (SELECT Pavadinimas FROM Lala.tipas WHERE tipas.TipasID = leidimas.TipasID), ' '),
      leidimas.Metai,
      leidimas.LeidimoNr,
      leidimas.PslSk,
      leidimas.ISBN,
      leidimas.eMetai,
      leidimas.eISBN,
      leidimas.eISSN,
      leidimas.DOI,
      busena.busena,
      CONCAT_WS(' ', (SELECT Pavadinimas FROM Lala.formatas WHERE formatas.FormatasID = leidimas.FormatasID), ' '),
      CONCAT_WS(' ', (SELECT Pavadinimas FROM Lala.virselistipas WHERE virselistipas.VirselisTipasID = leidimas.VirselisTipasID), ' ')
    ) as product_attribute
	

	 FROM 
        Lala.katalogas, 
        Lala.leidimas, 
        Lala.leidykla,
        Lala.busena
      INNER JOIN 
        Lala.leidimas as leidimas_img
      WHERE
        katalogas.KatalogasID = leidimas.KatalogasID AND
        katalogas.LeidyklaID = leidykla.LeidyklaID AND
        katalogas.KatalogasID = busena.KatalogasID AND
        katalogas.KatalogasID = leidimas_img.KatalogasID AND
        leidimas.NomNr != '' AND
        (leidimas.NomNr LIKE CONCAT(SUBSTRING(YEAR(NOW()) - 1, 3, 2),'-', '%') or leidimas.NomNr LIKE CONCAT(SUBSTRING(YEAR(NOW()), 3, 2),'-', '%'))
      GROUP BY
        leidimas.LeidimasID
      ORDER BY
        leidimas.LeidimasID ASC");

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    dump($row);
                    $new_product = new Product();
                    $new_product->name = array(1 => $row['name']);
                    $new_product->description = array(1 => $row['description']);
                    $new_product->reference = $row['reference'];
                    $new_product->weight = $row['weight'];
//                    $new_product->isbn = utf8_encode($row['isbn']);
                    $category_id = 2;
                    $new_product->id_category_default = $category_id;
                    $new_product->id_manufacturer = (int) Manufacturer::getIdByName($row['manufacturer']);
                    $new_product->link_rewrite = array(1 => Tools::link_rewrite($row['name']));
                    $new_product->quantity = 0;
                    $new_product->minimal_quantity = 1;
                    $new_product->price = 0;
                    $new_product->active = true;
                    $new_product->id_tax_rules_group = 0;
                    $new_product->on_sale = 0;
                    // Įtraukiama nauja prekė į naują duomenų bazę
                    if ($new_product->add()) {
                        echo 'Prekė sėkmingai įtraukta į duomenų bazę!';
                    } else {
                        echo 'Klaida įtraukiant prekę į duomenų bazę';
                    }
                }
                die();
            }
        }
        return $output . $this->renderForm();
    }
    /**
     * Create the structure of your form.
     */
    protected function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Database Import Settings'),
                    'icon' => 'icon-database'
                ),
                'input' => array(
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'label' => $this->l('Prekių nuoroda:'),
                        'name' => 'DBIMPORTMODULE_SERVER',
                        'required' => true,
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'label' => $this->l('Prisijungimo vardas:'),
                        'name' => 'DBIMPORTMODULE_USERNAME',
                        'required' => true,
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'label' => $this->l('Prisijungimo slaptažodis:'),
                        'name' => 'DBIMPORTMODULE_PASSWORD',
                        'required' => true,
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'label' => $this->l('Tiekėjo kodas:'),
                        'name' => 'DBIMPORTMODULE_DATABASE',
                        'required' => true,
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Import'),
                    'class' => 'btn btn-default pull-right',
                    'name' => 'submitDbImport',
                )));
        /**
         * Create the form that will be displayed in the configuration of your module.
         */
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitDbImport';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($fields_form));
    }
    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'DBIMPORTMODULE_SERVER' => Tools::getValue('DBIMPORTMODULE_SERVER', Configuration::get('DBIMPORTMODULE_SERVER')),
            'DBIMPORTMODULE_USERNAME' => Tools::getValue('DBIMPORTMODULE_USERNAME', Configuration::get('DBIMPORTMODULE_USERNAME')),
            'DBIMPORTMODULE_PASSWORD' => Tools::getValue('DBIMPORTMODULE_PASSWORD', Configuration::get('DBIMPORTMODULE_PASSWORD')),
            'DBIMPORTMODULE_DATABASE' => Tools::getValue('DBIMPORTMODULE_DATABASE', Configuration::get('DBIMPORTMODULE_DATABASE')),
        );
    }
    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }
    public function hookDisplayHome()
    {
        $this->context->smarty->assign(array(
            'DBIMPORTMODULE' => Configuration::get('DBIMPORTMODULE')
        ));
        return $this->display(__FILE__, 'views/templates/hook/home.tpl');
    }

}